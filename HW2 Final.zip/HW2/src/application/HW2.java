package application;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class HW2 extends Application {

    private ListView<String> questionListView;
    private TextField questionInput, answerInput;
    private Button addButton, deleteButton;
    private QuestionList questionList = new QuestionList();
    private AnswerList answerList = new AnswerList();

    @Override
    public void start(Stage primaryStage) {
        questionListView = new ListView<>();
        questionInput = new TextField();
        answerInput = new TextField();
        addButton = new Button("Add Question & Answer");
        deleteButton = new Button("Delete");

        addButton.setOnAction(e -> addQuestion());
        deleteButton.setOnAction(e -> deleteSelected());

        VBox vbox = new VBox(10, questionInput, answerInput, addButton, deleteButton, questionListView);
        Scene scene = new Scene(vbox, 500, 400);

        primaryStage.setScene(scene);
        primaryStage.setTitle("Question and Answer");
        primaryStage.show();

        refreshListView();
    }

    private void addQuestion() {
        String questionText = questionInput.getText().trim();
        String answerText = answerInput.getText().trim();
        
        if (!questionText.isEmpty() && !answerText.isEmpty()) {
            if (questionList.contains(questionText, answerText, answerList)) {
                showAlert("Duplicate Entry", "Question and answer is available.");
                return;
            }
            
            Question question = new Question(String.valueOf(questionList.getQuestions().size() + 1), questionText);
            questionList.addQuestion(question);
            answerList.addAnswer(new Answer(question.getId(), answerText));
            questionInput.clear();
            answerInput.clear();
            refreshListView();
        } else {
            showAlert("Invalid Input", "Both question and answer must be provided.");
        }
    }

    private void deleteSelected() {
        int selectedIndex = questionListView.getSelectionModel().getSelectedIndex();
        if (selectedIndex >= 0) {
            String selectedItem = questionListView.getItems().get(selectedIndex);
            
            // Extract the question ID (assuming it follows the pattern "ID. Question")
            String questionId = selectedItem.split("\\.")[0].trim(); 
            
            questionList.deleteQuestion(questionId);
            answerList.deleteAnswersByQuestionId(questionId);
            
            // Refresh UI
            refreshListView();
        } else {
            showAlert("Invalid Deletion", "No item selected to delete.");
        }
    }

    private void refreshListView() {
        List<String> displayItems = questionList.getQuestions().stream()
                .map(q -> q.getId() + ". " + q.getText() + "\n  Answer: " + answerList.getAnswerByQuestionId(q.getId()))
                .collect(Collectors.toList());
        questionListView.getItems().setAll(displayItems);
    }

    private void showAlert(String title, String message) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    public static void main(String[] args) {
        launch(args);
    }
}

class Question {
    private String id;
    private String text;

    public Question(String id, String text) {
        this.id = id;
        this.text = text;
    }

    public String getId() {
        return id;
    }

    public String getText() {
        return text;
    }
}

class Answer {
    private String questionId;
    private String text;

    public Answer(String questionId, String text) {
        this.questionId = questionId;
        this.text = text;
    }

    public String getQuestionId() {
        return questionId;
    }

    public String getText() {
        return text;
    }
}

class QuestionList {
    private List<Question> questions = new ArrayList<>();

    public void addQuestion(Question question) {
        questions.add(question);
    }

    public void deleteQuestion(String id) {
        questions.removeIf(q -> q.getId().equals(id));
    }

    public List<Question> getQuestions() {
        return questions;
    }
    
    public boolean contains(String questionText, String answerText, AnswerList answerList) {
        return questions.stream().anyMatch(q -> q.getText().equalsIgnoreCase(questionText) && answerList.getAnswerByQuestionId(q.getId()).equalsIgnoreCase(answerText));
    }
}

class AnswerList {
    private List<Answer> answers = new ArrayList<>();

    public void addAnswer(Answer answer) {
        answers.add(answer);
    }

    public void deleteAnswersByQuestionId(String questionId) {
        answers.removeIf(a -> a.getQuestionId().equals(questionId));
    }

    public String getAnswerByQuestionId(String questionId) {
        return answers.stream()
                .filter(a -> a.getQuestionId().equals(questionId))
                .map(Answer::getText)
                .findFirst()
                .orElse("No answer available.");
    }
}